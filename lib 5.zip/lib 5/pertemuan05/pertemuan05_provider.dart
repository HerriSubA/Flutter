import 'package:flutter/material.dart';

class Pertemuan05Provider extends ChangeNotifier {
  //Status soal dipelajari saat ini ?

  //Initialisasi nilai awal
  bool _diSekolah = false;
  bool _diPraktik = true;
  bool _diKursus = false;

  //Return nilai disekolah, dipraktik, dst. (Konsep OOP setter||getter)
  bool get statusSekolah => _diSekolah;
  bool get statusPraktik => _diPraktik;
  bool get statusKursus => _diKursus;

  //Perubahan state. (Konsep Listen pada stateManajemen)
  set setSekolah(val) {
    _diSekolah = val;
    notifyListeners();
  }

  set setPraktik(val) {
    _diPraktik = val;
    notifyListeners();
  }

  set setKursus(val) {
    _diKursus = val;
    notifyListeners();
  }
}
