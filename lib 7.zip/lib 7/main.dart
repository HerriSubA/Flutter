import 'package:flutter/material.dart';
import 'package:flutter_application_7/pertemuan07/pertemuan07_provider.dart';
import 'package:flutter_application_7/pertemuan07/pertemuan07_screen.dart';
import 'package:provider/provider.dart';

void main() {
  runApp(MultiProvider(providers: [
    ChangeNotifierProvider(create: (_) => Pertemuan07Provider()),
  ], child: const MyApp()));
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.light,
        primarySwatch: Colors.purple,
      ),
      home: const Pertemuan07Screen(),
    );
  }
}
