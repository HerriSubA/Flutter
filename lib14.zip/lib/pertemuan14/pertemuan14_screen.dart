import 'package:flutter/material.dart';

class pertemuan14Screen extends StatefulWidget {
  const pertemuan14Screen({super.key});

  @override
  State<pertemuan14Screen> createState() => _pertemuan14ScreenState();
}

class _pertemuan14ScreenState extends State<pertemuan14Screen> {
  DateTime _date = DateTime.now();
  TimeOfDay? _timeinput = TimeOfDay.now();
  TextEditingController? _time;
  DateTimeRange? _dateRange;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Pertemuan 14'),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16.0),
        child: Column(
          children: [
            //DatePicker
            Row(
              children: [
                const Text('Tanggal: '),
                const SizedBox(width: 10),
                Expanded(
                  child: InputDatePickerFormField(
                    initialDate: _date,
                    firstDate: DateTime(1990),
                    lastDate: DateTime(2250),
                    onDateSubmitted: (date) {
                      setState(() {
                        _date = date;
                        print(_date);
                      });
                    },
                  ),
                ),
                IconButton(
                    onPressed: () async {
                      var res = await showDatePicker(
                          context: context,
                          initialDate: _date,
                          firstDate: DateTime(2000),
                          lastDate: DateTime(2500));

                      if (res != null) {
                        setState(() {
                          _date = res;
                          _dateRange = null;
                        });
                      }
                    },
                    icon: const Icon(Icons.date_range))
              ],
            ),
            //Time Picker
            Row(
              children: [
                const Text('Jam: '),
                const SizedBox(width: 10),
                Expanded(
                    child: TextField(
                  enabled: false,
                  controller: _time,
                  decoration: const InputDecoration(labelText: 'Jam'),
                )),
                IconButton(
                    onPressed: () async {
                      var res = await showTimePicker(
                        context: context,
                        initialTime: TimeOfDay.now(),
                      );
                      if (res != null) {
                        setState(() {
                          _timeinput = res;
                          _time =
                              TextEditingController(text: res.format(context));
                        });
                      }
                    },
                    icon: const Icon(Icons.timer))
              ],
            ),
            //Date Time Range
            Row(
              children: [
                const Text('Rentang Tanggal: '),
                const SizedBox(width: 10),
                Expanded(
                  child: TextField(
                    enabled: false,
                    controller: _dateRange != null
                        ? TextEditingController(
                            text:
                                '${_dateRange!.start.toString().split(' ')[0]} - ${_dateRange!.end.toString().split(' ')[0]}')
                        : null,
                    decoration:
                        const InputDecoration(labelText: 'Rentang Tanggal'),
                  ),
                ),
                IconButton(
                  onPressed: () async {
                    var res = await showDateRangePicker(
                      context: context,
                      firstDate: DateTime(2000),
                      lastDate: DateTime(2500),
                    );

                    if (res != null) {
                      setState(() {
                        _dateRange = res;
                        _time = null;
                      });
                    }
                  },
                  icon: const Icon(Icons.calendar_today),
                ),
              ],
            ),
            ListTile(
              title: const Text('Tanggal Terpilih'),
              subtitle: Text(_date.toString().split(' ')[0]),
            ),
            ListTile(
              title: const Text('Jam Terpilih'),
              subtitle: Text("${_timeinput!.hour}: ${_timeinput!.minute}"),
            ),
            if (_dateRange != null)
              ListTile(
                title: const Text('Rentang Tanggal'),
                subtitle: Text(
                    '${_dateRange!.start.toString().split(' ')[0]} - ${_dateRange!.end.toString().split(' ')[0]}'),
              ),
            const Divider(),
          ],
        ),
      ),
    );
  }
}
