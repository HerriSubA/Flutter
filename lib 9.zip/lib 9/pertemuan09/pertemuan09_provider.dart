import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';

class twitter extends StatelessWidget {
  const twitter({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Inbox'),
      ),
      body: Center(
          child: Text(
        'Abangda Ganteng',
        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 30),
      )),
    );
  }
}
